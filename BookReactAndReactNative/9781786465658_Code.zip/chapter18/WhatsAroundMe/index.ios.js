/*import React from 'react';
import {
  AppRegistry,
  View,
  MapView,
} from 'react-native';

import styles from './styles';

const WhatsAroundMe = () => (
  <View style={styles.container}>
    <MapView
      style={styles.mapView}
      showsUserLocation
      followUserLocation
    />
  </View>
);

AppRegistry.registerComponent(
  'WhatsAroundMe',
  () => WhatsAroundMe
);*/
import './index.js';
