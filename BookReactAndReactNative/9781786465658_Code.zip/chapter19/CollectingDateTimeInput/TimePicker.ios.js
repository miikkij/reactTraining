import React, { PropTypes } from 'react';
import {
  Text,
  View,
  DatePickerIOS,
} from 'react-native';

import styles from './styles';

// A simple abstraction that adds a label to
// the "<DatePickerIOS>" component.
const DatePicker = (props) => (
  <View style={styles.datePickerContainer}>
    <Text style={styles.datePickerLabel}>
      {props.label}
    </Text>
    <DatePickerIOS mode="time" {...props} />
  </View>
);

DatePicker.propTypes = {
  label: PropTypes.string,
};

export default DatePicker;
