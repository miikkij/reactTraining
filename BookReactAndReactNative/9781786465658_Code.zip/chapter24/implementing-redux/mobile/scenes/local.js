import all from './all';

export default Object.assign({}, all);
