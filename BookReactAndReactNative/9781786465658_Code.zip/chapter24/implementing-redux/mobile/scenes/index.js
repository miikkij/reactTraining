import allScene from './all';
import localScene from './local';

export { allScene };
export { localScene };
