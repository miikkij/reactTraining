import React from 'react';
import { PageHeader } from 'react-bootstrap';

export default () => (
  <section>
    <PageHeader>Home</PageHeader>
    <p>Some react-bootstrap examples...</p>
  </section>
);
