import React from 'react';

export default () => (<h1>First</h1>);
