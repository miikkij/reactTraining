import React from 'react';

export default () => (<p>Second</p>);
